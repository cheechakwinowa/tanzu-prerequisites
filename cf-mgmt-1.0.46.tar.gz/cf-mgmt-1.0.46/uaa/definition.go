package uaa

//go:generate counterfeiter -o fakes/fake_mgr.go uaa.go Manager
