&larr; [back to Commands](../README.md)

# `cf-mgmt-config update-orgs`

`update-orgs` command allows updating orgs.yml

## Command Usage
```
Usage:
  cf-mgmt-config [OPTIONS] update-orgs [update-orgs-OPTIONS]

Help Options:
  -h, --help                                Show this help message

[update-orgs command options]
  --config-dir=                     Name of the config directory (default: config) [$CONFIG_DIR]
  --enable-delete-orgs=[true|false] Enable delete orgs option
```
