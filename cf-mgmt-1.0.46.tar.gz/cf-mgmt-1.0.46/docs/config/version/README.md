&larr; [back to Commands](../README.md)

# `cf-mgmt-config version`

Displays version

## Command Usage

```
Usage:
  cf-mgmt-config [OPTIONS] version

Help Options:
  -h, --help      Show this help message
```
