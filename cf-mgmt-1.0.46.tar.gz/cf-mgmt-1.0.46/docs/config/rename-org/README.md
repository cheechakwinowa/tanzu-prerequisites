&larr; [back to Commands](../README.md)

# `cf-mgmt-config rename-org`

`rename-org` command will rename and update all org configuration files

## Command Usage
```
error: Usage:
  cf-mgmt-config [OPTIONS] rename-org [rename-org-OPTIONS]

Help Options:
  -h, --help            Show this help message

[rename-org command options]
  --config-dir= Name of the config directory (default: config) [$CONFIG_DIR]
  --org=        Org name
  --new-org=    Org name to rename to
```
