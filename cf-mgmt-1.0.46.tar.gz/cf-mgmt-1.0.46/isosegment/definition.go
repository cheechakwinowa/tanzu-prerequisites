package isosegment

//go:generate counterfeiter -o fakes/fake_cf_client.go types.go CFClient
