package ldap

//go:generate counterfeiter -o fakes/fake_connection.go connection.go Connection
